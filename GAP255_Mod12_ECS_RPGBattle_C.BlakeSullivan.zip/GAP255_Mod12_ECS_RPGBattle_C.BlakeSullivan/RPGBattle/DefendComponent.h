#pragma once

#include "Component.h"
#include "StatComponent.h"
#include "RPGCharacterEntity.h"
#include "ComponentManager.h"


struct DefendComponent : public Component
{
public:
	DefendComponent(RPGCharacterEntity self, RPGCharacterEntity target)
		: m_self(self)
		, m_target(target)
	{}

	void Update() override {}
	void Display() override {}

	// Blocking will decrease damage by block amount, and boost a stat.
	void Block() {
		ComponentManager::GetInstance()->GetComponent<StatComponent>(m_self)->block = m_blockValue;
		ComponentManager::GetInstance()->GetComponent<StatComponent>(m_self)->mana + m_replenish;
	}

private:
	RPGCharacterEntity m_self;
	RPGCharacterEntity m_target;
	float m_blockValue = 5;
	float m_replenish = 15;
};

