#include "StatComponent.h"

StatComponent::StatComponent(Health health, Stamina stamina, Mana mana)
	: health(health), stamina(stamina), mana(mana)
{}

// Updates the stat by adding regen amount to value.
void StatComponent::Update() {
	health.Regen();
	stamina.Regen();
	mana.Regen();
}

// Prints all stats.
void StatComponent::Display() {
	health.Display();
	stamina.Display();
	mana.Display();
}

// Decrease Health, reduced by block.
void StatComponent::Damage(float amount) {
	if (block > 0) {
		std::cout << "You blocked " << block << " damage.\n";
	}
	amount -= std::min(block, amount);
	health.Modify(-amount);
}
