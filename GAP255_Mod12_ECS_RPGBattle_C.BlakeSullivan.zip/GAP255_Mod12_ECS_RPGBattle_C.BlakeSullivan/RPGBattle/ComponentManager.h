#pragma once

#include <map>
#include <vector>

#include "Component.h"
#include "RPGCharacterEntity.h"

typedef std::map<RPGCharacterEntity, Component*> ComponentMap;


// A singleton.
class ComponentManager {
public:
	template<typename T>
	const char* GetTypeKey() {
		return typeid(T).name();
	}

	template<typename T>
	void RegisterComponent() {
		m_components[GetTypeKey<T>()] = ComponentMap();
	}

	template<typename T>
	void AddComponent(RPGCharacterEntity character, T* component) {
		const char* typeName = GetTypeKey<T>();
		ComponentMap& components = m_components[typeName];
		components[character] = component;
	}

	template<typename T>
	T* GetComponent(RPGCharacterEntity character) {
		const char* typeName = GetTypeKey<T>();
		ComponentMap& components = m_components[typeName];
		if (components.find(character) == components.end()) {
			return nullptr;
		}
		return reinterpret_cast<T*>(components[character]);
	}

	void Update() {
		for (auto componentMap : m_components) {
			for (auto component : componentMap.second) {
				component.second->Update();
			}
		}
	}

	void Display() {
		for (auto componentMap : m_components) {
			for (auto component : componentMap.second) {
				component.second->Display();
			}
		}
	}
	// Singleton Creation.
	static ComponentManager* GetInstance()
	{
		if (!s_instance)
			s_instance = new ComponentManager;
		return s_instance;
	}
private:
	ComponentManager() {}

	std::map<const char*, ComponentMap> m_components;
	static inline ComponentManager* s_instance = nullptr;
};
