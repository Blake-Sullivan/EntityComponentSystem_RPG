#pragma once

using RPGCharacterEntity = long;

RPGCharacterEntity CreateEntity();