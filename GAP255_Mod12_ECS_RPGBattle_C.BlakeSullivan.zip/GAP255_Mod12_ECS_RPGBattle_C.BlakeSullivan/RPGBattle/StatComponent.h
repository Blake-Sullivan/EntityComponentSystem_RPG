#pragma once

#include <iostream>
#include <algorithm>

#include "Component.h"
#include "Stat.h"

#include "ComponentManager.h"

// Holds an RPG Character's numerical stats - Health, Stamina, Mana. 
//	 - Also holds block value --> used in Damage().
struct StatComponent : public Component
{
	StatComponent(Health health, Stamina stamina, Mana mana);

	// Updates the stat by adding regen amount to value.
	void Update() override;

	// Prints all stats.
	void Display() override;

	// Decrease Health, reduced by block.
	void Damage(float amount);

	Health health;
	Stamina stamina;
	Mana mana;
	float block = 0;
};