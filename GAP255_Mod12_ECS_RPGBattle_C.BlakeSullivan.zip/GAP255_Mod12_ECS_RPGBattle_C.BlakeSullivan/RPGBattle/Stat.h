#pragma once

#include <iostream>
#include <string>
#include <algorithm>

// Still using a Stat class to handle stats
class Stat {
public:
	Stat(const std::string& name, float max, float regen)
		: m_name(name), m_value(max), m_max(max), m_regen(regen) {}

	// Updates the stat by adding regen amount to value.
	void Regen() {
		Modify(m_regen);
	}

	// Modifies the value by the given amount (can be negative).
	void Modify(float amount) {
		m_value = std::clamp(m_value + amount, 0.f, m_max);
	}

	// Gets the current value of the stat.
	float GetValue() const { return m_value; }

	// Gets the stat name.
	std::string GetName() const { return m_name; }

	// Prints the stat using std::cout.
	void Display() const {
		std::cout << "\t" << m_name << ": " << m_value << "\n";
	}

	friend void operator+(Stat& left, float& right) {
		left.Modify(right);
	}

	friend void operator-(Stat& left, float& right) {
		left.Modify(-right);
	}

private:
	std::string m_name;
	float m_value;
	float m_max;
	float m_regen;
};

// Represents a character's health.
class Health : public Stat {
public:
	Health(float max) : Stat("health", max, 1) {}
};

// Represents a character's stamina.
class Stamina : public Stat {
public:
	Stamina(float max) : Stat("stamina", max, 2) {}
};

// Represents a character's mana.
class Mana : public Stat {
public:
	Mana(float max) : Stat("mana", max, 5) {}		// CBS: Gave mana 5 regen
};