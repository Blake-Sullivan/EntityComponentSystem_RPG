#pragma once

#include "RPGCharacterEntity.h"

RPGCharacterEntity nextEntity = 0;

RPGCharacterEntity CreateEntity() { return nextEntity++; }
