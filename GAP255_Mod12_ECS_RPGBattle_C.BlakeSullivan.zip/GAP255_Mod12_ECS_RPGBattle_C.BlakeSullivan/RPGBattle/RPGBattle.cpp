#include <iostream>
#include <vector>
#include <map>
#include <algorithm>
#include <string>
#include <stdlib.h>

#include "NameComponent.h"
#include "StatComponent.h"
#include "AttackComponent.h"
#include "DefendComponent.h"
#include "ComponentManager.h"
#include "RPGCharacterEntity.h"

// Display function declaration - player's HUD.
void Display(int round, RPGCharacterEntity player, RPGCharacterEntity enemy);


// Runs the main game loop.
int main()
{
	std::cout << "------------------------------ RPG Battle! ------------------------------\n";
	std::cout << "You are a Mage  :  vs. a Warrior.\n";

	// Prepare the ComponentManager for all components.
	ComponentManager::GetInstance()->RegisterComponent<NameComponent>();
	ComponentManager::GetInstance()->RegisterComponent<StatComponent>();
	ComponentManager::GetInstance()->RegisterComponent<AttackComponent>();
	ComponentManager::GetInstance()->RegisterComponent<DefendComponent>();

	RPGCharacterEntity warrior = CreateEntity();
	RPGCharacterEntity mage = CreateEntity();

	// Assign warrior's components.		// NOTE: Warrior functions as an AI opponent, does not need to block (i.e. no <DefendComponent>).
	ComponentManager::GetInstance()->AddComponent<NameComponent>(warrior, new NameComponent(std::string("Warrior")) );
	ComponentManager::GetInstance()->AddComponent<StatComponent>(warrior, new StatComponent(Health(100), Stamina(10), Mana(0)));
	ComponentManager::GetInstance()->AddComponent<AttackComponent>(warrior, new AttackComponent(warrior, mage) );

	// Assign mage's components.
	ComponentManager::GetInstance()->AddComponent<NameComponent>(mage, new NameComponent(std::string("Mage")));
	ComponentManager::GetInstance()->AddComponent<StatComponent>(mage, new StatComponent(Health(50), Stamina(10), Mana(200)));
	ComponentManager::GetInstance()->AddComponent<AttackComponent>(mage, new AttackComponent(mage, warrior));
	ComponentManager::GetInstance()->AddComponent<DefendComponent>(mage, new DefendComponent(mage, warrior));

	int round = 1;
	while (true) {
		Display(round, mage, warrior);

		std::cout << "\nEnter command: ";
		std::string command;
		std::getline(std::cin, command);
		if (command == "attack" || command == "a") {
			ComponentManager::GetInstance()->GetComponent<AttackComponent>(mage)->Attack(AttackType::Spell);
		}
		else if (command == "block" || command == "b") {
			ComponentManager::GetInstance()->GetComponent<DefendComponent>(mage)->Block();
		}
		else if (command == "quit" || command == "q") {
			break;
		}

		// AI opponent attacks back.
		ComponentManager::GetInstance()->GetComponent<AttackComponent>(warrior)->Attack(AttackType::Melee);
		
		round++;
	}

return 0;
}

// Outputs updated information to console screen.
void Display(int round, RPGCharacterEntity player, RPGCharacterEntity enemy)
{
	std::cout << std::endl << "________________________ Round: " << round << " ________________________" << std::endl;
	std::cout << std::endl << " (a)ttack   |   (b)lock   |   (q)uit" << std::endl << std::endl;
	
	ComponentManager::GetInstance()->Update();

	std::cout << ComponentManager::GetInstance()->GetComponent<NameComponent>(player)->GetName() << "\n";
	ComponentManager::GetInstance()->GetComponent<StatComponent>(player)->Display();
	std::cout << ComponentManager::GetInstance()->GetComponent<NameComponent>(enemy)->GetName() << "\n";
	ComponentManager::GetInstance()->GetComponent<StatComponent>(enemy)->Display();
}