#pragma once

struct Component
{
    virtual void Update() = 0;
    virtual void Display() = 0;
};