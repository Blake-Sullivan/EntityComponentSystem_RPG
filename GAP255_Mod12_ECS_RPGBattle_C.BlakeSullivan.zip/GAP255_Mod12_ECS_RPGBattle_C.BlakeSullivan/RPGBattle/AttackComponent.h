#pragma once

#include "Component.h"
#include "RPGCharacterEntity.h"

// Type of attack --> Attack() behaves differently depending on attack type.
enum class AttackType {
	Melee,
	Ranged,
	Spell
};

class AttackComponent : public Component
{
public:
	AttackComponent(RPGCharacterEntity self, RPGCharacterEntity target);
	
	void Update() override {}
	void Display() override {}

	// Attacks a target.
	void Attack(AttackType attack);

private:
	RPGCharacterEntity m_self;
	RPGCharacterEntity m_target;
	float m_staminaCost = 4;
	float m_manaCost = 25;
	float m_attackMultiplier = 1;
};