#include <iostream>
#include <string>
#include <stdlib.h>

#include "AttackComponent.h"
#include "ComponentManager.h"
#include "NameComponent.h"
#include "StatComponent.h"
#include "Stat.h"



AttackComponent::AttackComponent(RPGCharacterEntity self, RPGCharacterEntity target)
	: m_self(self)
	, m_target(target)
{}

// Attacks a target with a melee - uses stamina.
void AttackComponent::Attack(AttackType attack) {
	// Attacking sets block to 0.
	ComponentManager::GetInstance()->GetComponent<StatComponent>(m_self)->block = 0;

	std::string statName;
	float statCheck, damage, resourceCost = 0;

	// Determine which type of attack is being performed, assign variables accordingly.
	switch(attack) 
	{
	case AttackType::Melee:
		statName = ComponentManager::GetInstance()->GetComponent<StatComponent>(m_self)->stamina.GetName();
		statCheck = ComponentManager::GetInstance()->GetComponent<StatComponent>(m_self)->stamina.GetValue();
		damage = (2 + rand() % 9) * m_attackMultiplier;
		resourceCost = m_staminaCost;
		break;

	case AttackType::Ranged:
		// Implement dexteriry & energy resource system.
		break;

	case AttackType::Spell:
		statName = ComponentManager::GetInstance()->GetComponent<StatComponent>(m_self)->mana.GetName();
		statCheck = ComponentManager::GetInstance()->GetComponent<StatComponent>(m_self)->mana.GetValue();
		damage = (4 + rand() % 12) * m_attackMultiplier;
		resourceCost = m_manaCost;
		break;
	}

	// Check if enough resource to attack.
	if (statCheck < resourceCost) {
		std::cout << statName <<"[" << statCheck << "] : not enough " << statName <<" to attack!\n";
		return;
	}

	// Apply resource cost, reduce appropriate resource.
	switch (attack)
	{
	case AttackType::Melee:
		ComponentManager::GetInstance()->GetComponent<StatComponent>(m_self)->stamina - m_staminaCost;
		break;

	case AttackType::Ranged:
		// ComponentManager::GetInstance()->GetComponent<StatComponent>(m_self)->energy - m_energyCost;
		break;

	case AttackType::Spell:
		ComponentManager::GetInstance()->GetComponent<StatComponent>(m_self)->mana - m_manaCost;
		break;
	}

	// Apply damage -> Reduce health stat.
	ComponentManager::GetInstance()->GetComponent<StatComponent>(m_target)->Damage(damage);

	// Display attack to console.
	std::string self = ComponentManager::GetInstance()->GetComponent<NameComponent>(m_self)->GetName();
	std::string target = ComponentManager::GetInstance()->GetComponent<NameComponent>(m_target)->GetName();
	switch (attack)
	{
	case AttackType::Melee:
		std::cout << self << " swings weapon at " << target << " for " << damage << " damage!\n";
		break;

	case AttackType::Ranged:
		std::cout << self << " shoots arrow at" << target << " for " << damage << " damage!\n";
		break;

	case AttackType::Spell:
		std::cout << self << " casts fireball at " << target << " for " << damage << " damage!\n";
		break;
	}
}